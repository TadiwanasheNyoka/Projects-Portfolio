﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG182Project1
{
    enum Opt
    {
        Capture = 1,
        Check,
        Display,
        Exit
    }
    internal class Program
    {
       static int[] arr = new int[4];
       static string ans1 = "Y";
       static string ans2 = "N";
       static int option = 0;
       static void Main(string[] args)
        {
            Program p = new Program();
           
            do
            {
                Console.WriteLine("1. Capture Details \n 2. Check Credit Qualification \n 3. Display Qualification Stats \n 4. Exit");
                Console.WriteLine("Enter an option");
                option = int.Parse(Console.ReadLine());

                if (option == 1)
                {
                    Capture();
                }
                else
               if (option == 2)
                {
                    Check();
                }
                else
                 if (option == 3)
                {
                    Display();

                }
                else
                if (option == 4)
                {
                    Environment.Exit(0);
                }
                Console.WriteLine("Enter a correct option");
                Console.WriteLine("Do you want to capture more applicants Y/N?");
                ans1 = Console.ReadLine();
                ans2 = Console.ReadLine();

                Console.ReadKey();
            }
            while (ans1.Equals("Y"));
        }
        public static void Capture()
        {
            Console.WriteLine("Capture Details:");
            Console.WriteLine("________________________________________________________");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Enter Applicant Name");
                Console.ReadLine();
                Console.WriteLine("Enter Employment status: \n 1.Employeed \n 2.Unemployeed ");
                Console.ReadLine();
                Console.WriteLine("Enter years in current job:");
                Console.ReadLine();
                Console.WriteLine("Enter years at current residence:");
                Console.ReadLine();
                Console.WriteLine("Enter amount of Salary:");
                Console.ReadLine();
                Console.WriteLine("Enter amount of non-mortage debt in months:");
                Console.ReadLine();
                Console.WriteLine("Enter number of children:");
                Console.ReadLine();
                break;
            }
        }
        public static void Check()
        {
            Console.WriteLine("Check Credit Qualification:");
            Console.WriteLine("________________________________________________________");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Enter Employment status: \n 1.Employeed \n 2.Unemployeed ");
                string status = Console.ReadLine();

                if (status == "1")
                {

                    Console.WriteLine("Enter years in current job:");
                    int job = int.Parse(Console.ReadLine());

                    if (job > 1)
                    {
                        Console.WriteLine("Enter years at current residence:");
                        int resid = int.Parse(Console.ReadLine());

                        if (resid > 2)
                        {
                            Console.WriteLine("Enter amount of non-mortage debt in months:");
                            int debt = int.Parse(Console.ReadLine());

                            if (debt < 2)
                            {
                                Console.WriteLine("Enter number of children:");
                                int children = int.Parse(Console.ReadLine());

                                if (children < 6)
                                {
                                    Console.WriteLine("Application Accepted ");
                                    Console.WriteLine("The number of people accepted:" + arr[i]);


                                }
                                else if (debt > 2 || children > 6)
                                {
                                    Console.WriteLine("Application Denied");
                                    Console.WriteLine("The number of people denied:" + arr[i]);
                                }
                            }

                        }
                    }
                    break;

                }
                
            }
        }
        public static void Display()
        {
            Console.WriteLine(" Display Qualification Stats:");
            Console.WriteLine("________________________________________________________");
            for (int x = 0; x <= arr.Length - 2; x++)
            {
                for (int y = 0; y <= arr.Length - 2; y++)
                {
                    if (arr[y] > arr[y + 1])
                    {
                        int temp = arr[y + 1];
                        arr[y + 1] = arr[y];
                        arr[y] = temp;
                        Console.WriteLine(arr[y]);
                    }
                }
            }
            Console.WriteLine("Display");
            Console.WriteLine("_________________________________________________________");
            for (int k = 0; k < arr.Length; k++)
            {
                Console.WriteLine(arr[k]);
            }
        }
    }
}
