﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Itumeleng_Namhla_Tadiwanashe_PRG182Project1
{
    enum menu
    { 
        Breakfast = 1,
        Combos,
        Chips,
        Burgers,
        Drinks,
        Checkout,
        Exit
    }
    enum Breakfast
    {
        BreakfastSpecial = 1,
        HashbrownEggs,
        SundaySpecial,
        Back
    }
    enum Combos
    {
        Uno_Combo = 1,
        Di_Combo,
        Tri_Combo,
        Back
    }
    enum Chips
    {
        Small_Chips = 1,
        Medium_Chips,
        Large_Chips,
        Back
    }
    enum Burgers
    {
        Hawaiian_Burger = 1,
        Cheese_Bruger,
        Double_Beef_Burger,
        Back
    }
    enum Drinks
    {
        Soft_Drinks = 1,
        Milkshakes,
        Juices,
        Hot_Drinks,
        Back
    }
    enum SoftDrinks
    {
        Coke = 1,
        Sprite,
        Lemon_Twist,
        Stoney,
        Back
    }
    enum Milkshakes
    {
        Chocolate = 1,
        Strawberry,
        Vanilla,
        Banana,
        Back
    }
    enum Juices
    {
        Orange = 1,
        Lemon,
        Mixed_Berry,
        Tropical,
        Lemonade,
        Back
    }
    enum Hot_Drinks
    {
        cappuccino = 1,
        Hot_Chocolate,
        Coffee,
        Tea,
        Back
    }
    internal class Program
    {
       static double Total = 0;
       static double SubTotal = 0;

       static double Amount = 0; 
       static List<string> Order = new List<string>();
       static string ans = "yes";
       static int option;
       static void Main(string[] args)
        {
            Program p = new Program();

            do
            {
                option = GetOption();
                if (option == 1)
                {
                    BreakfastMenu();
                }
                if (option == 2)
                {
                    ComboMenu();
                }
                if (option == 3)
                {
                    ChipsMenu();
                }
                if (option == 4)
                {
                    BurgersMenu();
                }
                if (option == 5)
                {
                    DrinksMenu();
                }
                if (option == 6)
                {
                    CheckOut();
                }
                if (option == 7)
                {
                    Environment.Exit(0);
                }
                Console.WriteLine("Do you want to continue yes/no?");
                ans = Console.ReadLine();
            }
            while (ans.Equals("yes"));
            Console.ReadKey();
        }

       public static int GetOption()
        {
            do
            {
                Console.WriteLine("Menu");
                Console.WriteLine("1. {0}", menu.Breakfast);
                Console.WriteLine("2. {0}", menu.Combos);
                Console.WriteLine("3. {0}", menu.Chips);
                Console.WriteLine("4. {0}", menu.Burgers);
                Console.WriteLine("5. {0}", menu.Drinks);
                Console.WriteLine("6. {0}", menu.Checkout);
                Console.WriteLine("7. {0}", menu.Exit);

                int option = int.Parse(Console.ReadLine());
                return option;
              
            }
            

            while (ans.Equals("yes"));
        }

        public static void BreakfastMenu()
        {
            bool back = false;
           

            Console.WriteLine("BreakFast");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. {0} \tR40", Breakfast.BreakfastSpecial);
                Console.WriteLine("2. {0} \tR20", Breakfast.HashbrownEggs);
                Console.WriteLine("3. {0} \tR60", Breakfast.SundaySpecial);
                Console.WriteLine("4. {0}", Breakfast.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                    if (option == 1)
                    {
                        Order.Add("Breakfast Special");
                        SubTotal += 40;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);

                    }
                    if (option == 2)
                    {
                        Order.Add("Hashbrown Eggs");
                        SubTotal += 20;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 3)
                    {
                        Order.Add("Sunday Special");
                        SubTotal += 60;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 4)
                    {
                        back = true;

                    }
                break;
            }

            while (ans.Equals("yes"));
            
        }
        public static void ComboMenu()
        {
            bool back = false;

            Console.WriteLine("Combos");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. {0} \tR55", Combos.Uno_Combo);
                Console.WriteLine("2. {0} \tR40", Combos.Di_Combo);
                Console.WriteLine("3. {0} \tR60", Combos.Tri_Combo);
                Console.WriteLine("4. {0} ", Combos.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                
                    if (option == 1)
                    {
                        Order.Add("Uno Combo");
                        SubTotal += 55;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 2)
                    {
                        Order.Add("Di Combo");
                        SubTotal += 40;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 3)
                    {
                        Order.Add("Tri Combo");
                        SubTotal += 60;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 4)
                    {
                        back = true;
                    }
                break;
            }
            while (ans.Equals("yes"));
        }

        public static void ChipsMenu()
        {
            bool back = false;

            Console.WriteLine("Chips");
            Console.WriteLine("_______________");

            do
            {

                Console.WriteLine("1. {0} \tR20", Chips.Small_Chips);
                Console.WriteLine("2. {0} \tR25", Chips.Medium_Chips);
                Console.WriteLine("3. {0} \tR30", Chips.Large_Chips);
                Console.WriteLine("4. {0} ", Chips.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                    if(option == 1)
                    {
                        Order.Add("Small Chips");
                        SubTotal += 20;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if(option == 2)
                    {
                        Order.Add("Medium Chips");
                        SubTotal += 25;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if(option == 3)
                    {
                        Order.Add("Large Chips");
                        SubTotal += 30;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if(option == 4)
                    {
                        back = true;
                    }
                break;
            }
            while (ans.Equals("yes")) ;
        }

        public static void BurgersMenu()
        {
            bool back = false;

            Console.WriteLine("Burgers");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. {0} \tR45", Burgers.Hawaiian_Burger);
                Console.WriteLine("2. {0} \tR25", Burgers.Cheese_Bruger);
                Console.WriteLine("3. {0} \tR35", Burgers.Double_Beef_Burger);
                Console.WriteLine("4. {0}", Burgers.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                    if(option == 1)
                    {
                        Order.Add("Hawaiian Burger");
                        SubTotal += 45;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 2)
                    {
                        Order.Add("Cheese Burger");
                        SubTotal += 25;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 3)
                    {
                        Order.Add("Double Cheese Burger");
                        SubTotal += 35;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 4)
                    {
                        back = true;
                    }
                break;
            }
            while (ans.Equals("yes")) ;
        }

        public static void DrinksMenu()
        {

            bool back = false;

            Console.WriteLine("Drinks");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. Soft Drinks \t R15");
                Console.WriteLine("2. Milkshakes \tR30");
                Console.WriteLine("3. Juices \tR20");
                Console.WriteLine("4. Hot Drinks \tR25");
                Console.WriteLine("5. Back");

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                if(option == 1)
                {
                    ShowSoftDrinks();
                }
                if (option == 2)
                {
                    ShowMilkshakes();
                }
                if (option == 3)
                {
                    ShowJuices();
                }
                if (option == 4)
                {
                    ShowHotDrinks();
                }
                if (option == 5)
                {
                    ShowSoftDrinks();
                }
            }
            while (ans.Equals("yes")) ;
        }
        public static void ShowSoftDrinks()
        {
            bool back = false;

            Console.WriteLine("Soft Drinks");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. {0} \tR15", SoftDrinks.Coke);
                Console.WriteLine("2. {0} \tR15", SoftDrinks.Sprite);
                Console.WriteLine("3. {0} \tR15", SoftDrinks.Lemon_Twist);
                Console.WriteLine("4. {0} \tR15", SoftDrinks.Stoney);
                Console.WriteLine("5. {0}", SoftDrinks.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

              
                    if(option == 1)
                    {
                        Order.Add("Coke 500ml");
                        SubTotal += 15;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }

                    if (option == 2)
                    {
                        Order.Add("Sprit 500ml");
                        SubTotal += 15;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }

                    if (option == 3)
                    {
                        Order.Add("Lemon_Twist 500ml");
                        SubTotal += 15;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }

                    if (option == 4)
                    {
                        Order.Add("Stoney 500ml");
                        SubTotal += 15;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }

                    if (option == 5)
                    {
                        back = true;
                    }
                break;
            }
            while (ans.Equals("yes"));
        }

        public static void ShowMilkshakes()
        {
            bool back = false;

            Console.WriteLine("Milkshakes");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. {0} \tR30", Milkshakes.Chocolate);
                Console.WriteLine("2. {0} \tR30", Milkshakes.Strawberry);
                Console.WriteLine("3. {0} \tR30", Milkshakes.Vanilla);
                Console.WriteLine("4. {0} \tR30", Milkshakes.Banana);
                Console.WriteLine("5. {0}", Milkshakes.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                    if (option == 1)
                    {
                        Order.Add("Chocolate Milkshake");
                        SubTotal += 30;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }

                    if (option == 2)
                    {
                        Order.Add("Strawberry Milkshake");
                        SubTotal += 30;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }

                    if (option == 3)
                    {
                        Order.Add("Vanilla Milkshake");
                        SubTotal += 30;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }

                    if (option == 4)
                    {
                        Order.Add("Banana Milkshake");
                        SubTotal += 30;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if(option == 5)
                    {
                        back = true;
                    }
            }
            while (ans.Equals("yes"));
        }

        public static void ShowJuices()
        {
            bool back = false;

            Console.WriteLine("Juice Drinks");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. {0} \tR23", Juices.Orange);
                Console.WriteLine("2. {0} \tR23", Juices.Lemon);
                Console.WriteLine("3. {0} \tR23", Juices.Mixed_Berry);
                Console.WriteLine("4. {0} \tR23", Juices.Tropical);
                Console.WriteLine("5. {0} \tR23", Juices.Lemonade);
                Console.WriteLine("6. {0}", Juices.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                    if (option == 1)
                    {
                        Order.Add("Orange Juice");
                        SubTotal += 23;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if(option == 2)
                    {
                        Order.Add("Lemon Juice");
                        SubTotal += 23;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 3)
                    {
                        Order.Add("Mixed_Berry Juice");
                        SubTotal += 23;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 4 )
                    {
                        Order.Add("Tropical Juice");
                        SubTotal += 23;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if (option == 2)
                    {
                        Order.Add("Lemonade Juice");
                        SubTotal += 23;
                        Console.WriteLine("How many would you like?");
                        Amount = double.Parse(Console.ReadLine());
                        Total = SubTotal * Amount;
                        Console.WriteLine("The total is R" + Total);
                    }
                    if(option == 6)
                    {
                        back = true;
                    } 
                break;
            }
            while (ans.Equals("yes"));
        }

        public static void ShowHotDrinks()
        {
            bool back = false;

            Console.WriteLine("Hot Drinks");
            Console.WriteLine("_______________");

            do
            {
                Console.WriteLine("1. {0} \tR25", Hot_Drinks.cappuccino);
                Console.WriteLine("2. {0} \tR20", Hot_Drinks.Hot_Chocolate);
                Console.WriteLine("3. {0} \tR15", Hot_Drinks.Coffee);
                Console.WriteLine("4. {0} \tR15", Hot_Drinks.Tea);
                Console.WriteLine("5. {0} ", Hot_Drinks.Back);

                Console.WriteLine("Please choose an option");
                int option = int.Parse(Console.ReadLine());

                if (option == 1)
                {
                    Order.Add("Cappuccino");
                    SubTotal += 25;
                    Console.WriteLine("How many would you like?");
                    Amount = double.Parse(Console.ReadLine());
                    Total = SubTotal * Amount;
                    Console.WriteLine("The total is R" + Total);
                }
                if (option == 2)
                {
                    Order.Add("Hot Chocolate");
                    SubTotal += 20;
                    Console.WriteLine("How many would you like?");
                    Amount = double.Parse(Console.ReadLine());
                    Total = SubTotal * Amount;
                    Console.WriteLine("The total is R" + Total);
                }
                if (option == 3)
                {
                    Order.Add("Coffee");
                    SubTotal += 15;
                    Console.WriteLine("How many would you like?");
                    Amount = double.Parse(Console.ReadLine());
                    Total = SubTotal * Amount;
                    Console.WriteLine("The total is R" + Total);
                }
                if (option == 4)
                {
                    Order.Add("Tea");
                    SubTotal += 15;
                    Console.WriteLine("How many would you like?");
                    Amount = double.Parse(Console.ReadLine());
                    Total = SubTotal * Amount;
                    Console.WriteLine("The total is R" + Total);
                }
                if (option == 5)
                {
                    back = true;
                }
                break;
            }
            while (ans.Equals("yes"));
        }

        public static void CheckOut()
        {
            Console.WriteLine("Your order:");
            foreach (var item in Order)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Your total amounts to: {0}", Total);
        }

    }
}
