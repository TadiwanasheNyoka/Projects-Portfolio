﻿using assignment.Business_Logic_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace assignment.DataLayer
{
    internal class DataCapturer_FileHandler
    {
        string path = "DataCapturers.txt";
        public void WriteToFile(User manager)
        {
          
            try
            {
                if(!File.Exists(path))
                {
                    File.Create(path).Close();
                }
                using (StreamWriter writer =File.AppendText(path))
                {
                    writer.WriteLine($"{manager.UserName},{manager.Password}");
                }
                Console.WriteLine("Data Capturer information written to the file.");
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine($"Error writing to file");
            }

        }
        public Boolean ReadFromFile(User user)
        {
          

            try
            {
                string[] lines = File.ReadAllLines(path);

                foreach(string line in lines)
                {
                    string[] data = line.Split(','); 
                    if(data.Length == 2 && data[0] == user.UserName && data[1] == user.Password)
                    {
                        Console.WriteLine("Data Captured in verfied");
                        return true;
                    }
                }
                Console.WriteLine("Data Capturer information not found");
                return false;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error reading from file");
                return false;
            }


        }

        public void RegisterUser(User user)
        {
            try
            {
                string data = $"{user.UserName},{user.Password}";

                File.AppendAllLines(path,new[] {data});
            }
            catch(Exception e) 
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error with registering user");
            }
        }
    }
}
